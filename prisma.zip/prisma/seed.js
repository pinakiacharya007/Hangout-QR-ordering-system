const { PrismaClient } = require("@prisma/client");
const crypto = require("crypto");
const prisma = new PrismaClient();

// Same scheme as src/lib/auth.js (scrypt, "salt:hash") — kept duplicated here since
// this script runs standalone via `node prisma/seed.js`, outside the Next.js app.
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

const DEFAULT_ADMIN_USERNAME = "admin";
const DEFAULT_ADMIN_PASSWORD = "admin123";

async function main() {
  console.log("Seeding TableTap demo data...");

  // Wipe existing demo data for a clean slate
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
  await prisma.review.deleteMany();
  await prisma.tableSession.deleteMany();
  await prisma.table.deleteMany();
  await prisma.menuItem.deleteMany();
  await prisma.category.deleteMany();
  await prisma.notification.deleteMany();
  await prisma.restaurant.deleteMany();

  const restaurant = await prisma.restaurant.create({
    data: {
      id: "demo-restaurant",
      name: "Spice Route Kitchen",
      adminUsername: DEFAULT_ADMIN_USERNAME,
      adminPasswordHash: hashPassword(DEFAULT_ADMIN_PASSWORD),
    },
  });

  const categoriesData = [
    {
      name: "Starters",
      items: [
        { name: "Paneer Tikka", price: 220, veg: true, description: "Char-grilled cottage cheese, smoky masala marinade" },
        { name: "Chicken 65", price: 260, veg: false, description: "Crispy fried chicken tossed in curry leaf tempering" },
        { name: "Veg Spring Rolls", price: 180, veg: true, description: "Crisp rolls with julienned vegetables" },
      ],
    },
    {
      name: "Rice & Biryani",
      items: [
        { name: "Veg Biryani", price: 210, veg: true, description: "Fragrant basmati layered with spiced vegetables" },
        { name: "Chicken Biryani", price: 280, veg: false, description: "Slow-cooked dum biryani with tender chicken" },
        { name: "Jeera Rice", price: 150, veg: true, description: "Basmati rice tempered with cumin" },
      ],
    },
    {
      name: "Mains",
      items: [
        { name: "Paneer Butter Masala", price: 240, veg: true, description: "Cottage cheese in a rich tomato-butter gravy" },
        { name: "Butter Chicken", price: 300, veg: false, description: "Classic tandoori chicken in creamy tomato sauce" },
        { name: "Dal Tadka", price: 170, veg: true, description: "Yellow lentils tempered with garlic and ghee" },
      ],
    },
    {
      name: "Beverages",
      items: [
        { name: "Masala Chai", price: 40, veg: true, description: "Spiced Indian tea" },
        { name: "Sweet Lassi", price: 70, veg: true, description: "Chilled yogurt-based sweet drink" },
        { name: "Cold Coffee", price: 90, veg: true, description: "Blended coffee with ice cream" },
      ],
    },
  ];

  for (let i = 0; i < categoriesData.length; i++) {
    const cat = categoriesData[i];
    const category = await prisma.category.create({
      data: { restaurantId: restaurant.id, name: cat.name, sortOrder: i },
    });
    for (const item of cat.items) {
      await prisma.menuItem.create({
        data: {
          restaurantId: restaurant.id,
          categoryId: category.id,
          name: item.name,
          price: item.price,
          veg: item.veg,
          description: item.description,
          available: true,
          isBestseller: item.name.includes("Biryani") || item.name.includes("Butter Chicken") || item.name.includes("Paneer Tikka"),
        },
      });
    }
  }

  // Pre-seed Tables 1 through 12
  for (let t = 1; t <= 12; t++) {
    await prisma.table.create({
      data: { restaurantId: restaurant.id, number: t },
    });
  }

  console.log("Done! Demo restaurant id: demo-restaurant with 12 tables.");
  console.log(`Admin login:   username "${DEFAULT_ADMIN_USERNAME}", password "${DEFAULT_ADMIN_PASSWORD}" (change it from the dashboard)`);
  console.log("Admin view:    /admin/demo-restaurant");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });